# Mixture of Scars (MoS) & SCache O(1) — Adversarial Red-Team Replication Package (v1.0.0)

**Author:** Julio Cesar Reis Filho (Byte-OD Research)

## Contents
- `scar_cache/`: Core PyTorch implementation of `MoSLinear`, `MultiSlotSCache`, and HuggingFace drop-in `SCacheDynamicCache`.
- `scripts/adversarial_mos_scache_suite.py`: Full 7-Vector Red-Team Falsification Suite (recursive storage-pointer byte audit + active causality ablation + out-of-domain ASVD outlier resilience + long-range recall + DoS immunity).
- `tests/test_adversarial_mos_scache.py`: Automated `pytest` verification harness.
- `benchmark_results/adversarial_mos_scache_report.json`: Raw audited telemetry from execution on `Qwen/Qwen2.5-0.5B-Instruct` (24L) and `Qwen 2.5 72B MoS` (80L).

## One-Command Reproduction
```bash
pip install torch transformers safetensors pytest numpy
python scripts/adversarial_mos_scache_suite.py
pytest tests/test_adversarial_mos_scache.py -v
```
